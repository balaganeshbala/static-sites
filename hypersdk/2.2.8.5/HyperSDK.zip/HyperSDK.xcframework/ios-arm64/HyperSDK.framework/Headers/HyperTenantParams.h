//
//  HyperTenantParams.h
//  HyperSDK
//
//  Copyright © 2024 Juspay Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HyperTenantParams : NSObject

@property (nonatomic, strong) NSString * _Nullable clientId;
@property (nonatomic, strong) NSString * tenantId;
@property (nonatomic, strong) NSString * releaseConfigURL;
@property (nonatomic, strong) NSDictionary<NSString *, NSString *> * _Nullable releaseConfigHeaders;
@property (nonatomic, strong) NSString * _Nullable baseContent;
@property (nonatomic, strong) NSArray<NSString *> * _Nullable moduleNames;

@end

NS_ASSUME_NONNULL_END
