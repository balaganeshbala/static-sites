//
//  BridgeModule.h
//  HyperSDK
//
//  Copyright © Juspay Technologies. All rights reserved.
//

#ifndef BridgeModule_h
#define BridgeModule_h


typedef void (^HyperSDKCallback)(NSDictionary<NSString*, id>* _Nullable data);

@protocol BridgeModule <NSObject>
@required

- (void)setBridgeComponent:(id<BridgeComponent> _Nonnull)bridgeComponent;

- (NSArray<NSObject *> * _Nonnull)getJSIntefaces;

- (NSArray<NSString *> * _Nonnull)getEventsToWhitelist;

- (void)terminate;


@optional

- (NSArray<NSString *> * _Nonnull)getRegisteredServices;

- (NSDictionary * _Nullable)process:(NSDictionary * _Nonnull)processPayload andMerchantCallback:(HyperSDKCallback _Nonnull)callback;

- (NSDictionary<NSString *, NSObject *> * _Nullable)getNamedJsInterfaces;


@end

#endif /* BridgeModule_h */
