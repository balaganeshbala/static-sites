require 'open-uri'
require 'uri'
require 'net/http'
require 'fileutils'

class String
    def red;            "\e[31m#{self}\e[0m" end
    def green;          "\e[32m#{self}\e[0m" end
    def yellow;         "\e[33m#{self}\e[0m" end
end

fuse_remote_url = "https://public.releases.juspay.in/hypersdk-asset-download/ios/Fuse.rb"

url = URI.parse(fuse_remote_url)
req = Net::HTTP::Get.new(url.path)
res = Net::HTTP.start(url.host, url.port, use_ssl: true) do |http|
    http.request(req)
end

script_dir = File.dirname(File.expand_path(__FILE__))
fuse_remote_file_path = File.join(script_dir, 'FuseRemote.rb')

if res.code == '200'
    File.open(fuse_remote_file_path, 'w') do |f|
        f.write res.body
    end
else
    puts ("[HyperSDK] Error downloading Fuse script - " + res.code).red
    return
end

args = ["ruby", fuse_remote_file_path, ARGV[0] || "true", "xcframework"]

# Append the 4th argument (ARGV[2]) only if it's not nil
args << ARGV[2] unless ARGV[2].nil?

if !system(*args)
    puts "[HyperSDK] Assets download failed.".red
end